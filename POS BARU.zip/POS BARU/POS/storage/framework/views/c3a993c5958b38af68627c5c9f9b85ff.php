<table class="table" id="tbl-cart">
  <thead>
    
        <th>Produk</th>
        <th>Qty</th>
        <th>Price</th>
    
    </thead>
<tbody>
    
</tbody>
</table><?php /**PATH D:\POS BARU\POS\resources\views/order/cart.blade.php ENDPATH**/ ?>