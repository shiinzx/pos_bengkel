@extends('templates.layout')

@section('title', 'About Page')

@section('content')
<div class="alert alert-warning" role="alert">
  <h4 class="alert-heading">Ini About Page</h4>
  <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laudantium facere ducimus sapiente temporibus deleniti animi fuga, sint ipsum doloribus</p>
</div>
@endsection