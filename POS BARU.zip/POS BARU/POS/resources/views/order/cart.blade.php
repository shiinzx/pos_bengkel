<table class="table" id="tbl-cart">
  <thead>
    
        <th>Produk</th>
        <th>Qty</th>
        <th>Price</th>
    
    </thead>
<tbody>
    
</tbody>
</table>