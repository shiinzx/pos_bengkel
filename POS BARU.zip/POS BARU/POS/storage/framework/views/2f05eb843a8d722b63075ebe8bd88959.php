<table class="table" id="tbl-cart">
  <thead>
    
        <th>Produk</th>
        <th>Qty</th>
        <th>Price</th>
    
    </thead>
<tbody>
    
</tbody>
</table><?php /**PATH C:\Users\ACER\OneDrive\ドキュメント\LARAVEL_POS\POS\resources\views/order/cart.blade.php ENDPATH**/ ?>