

<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="alert alert-secondary" role="alert">
  <h4 class="alert-heading">Ini Home Page</h4>
  <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laudantium facere ducimus sapiente temporibus deleniti animi fuga, sint ipsum doloribus</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\POS BARU\POS\resources\views/home.blade.php ENDPATH**/ ?>