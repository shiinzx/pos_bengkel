@extends('templates.layout')

@section('title', 'Contact Page')

@section('content')
<div class="alert alert-info" role="alert">
  <h4 class="alert-heading">Ini Contact Page</h4>
  <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laudantium facere ducimus sapiente temporibus deleniti animi fuga, sint ipsum doloribus</p>
</div>
@endsection