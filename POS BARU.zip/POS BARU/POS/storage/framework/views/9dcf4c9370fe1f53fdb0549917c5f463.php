

<?php $__env->startSection('title', 'Contact Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="alert alert-info" role="alert">
  <h4 class="alert-heading">Ini Contact Page</h4>
  <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laudantium facere ducimus sapiente temporibus deleniti animi fuga, sint ipsum doloribus</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\POS BARU\POS\resources\views/contact.blade.php ENDPATH**/ ?>