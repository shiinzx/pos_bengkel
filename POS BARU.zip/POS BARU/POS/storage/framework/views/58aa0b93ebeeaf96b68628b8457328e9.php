

<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('content'); ?>
<h1>INI ABOUT</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ACER\OneDrive\ドキュメント\LARAVEL_POS\POS\resources\views/about.blade.php ENDPATH**/ ?>