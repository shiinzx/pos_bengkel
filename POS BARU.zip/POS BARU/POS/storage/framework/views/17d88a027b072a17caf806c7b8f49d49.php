

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">Daftar Category</h3>
        <a href="<?php echo e(route('category.create')); ?>" class="btn btn-primary btn-sm">Tambah Category</a>
    </div>

    <div class="card-body">
        <table class="table table-bordered table-striped text-center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ct->id); ?></td>
                    <td><?php echo e($ct->name); ?></td>
                    <td><?php echo e($ct->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('category.edit', $ct->id)); ?>" 
                           class="btn btn-warning btn-sm">Edit</a>

                        <form action="<?php echo e(route('category.destroy', $ct->id)); ?>" 
                              method="POST" 
                              style="display:inline"
                              onsubmit="return confirm('Yakin mau hapus category <?php echo e($ct->name); ?>?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\POS BARU\POS\resources\views/customer/data.blade.php ENDPATH**/ ?>