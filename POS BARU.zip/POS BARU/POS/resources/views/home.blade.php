@extends('templates.layout')

@section('title', 'Home Page')

@section('content')
<div class="alert alert-secondary" role="alert">
  <h4 class="alert-heading">Ini Home Page</h4>
  <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laudantium facere ducimus sapiente temporibus deleniti animi fuga, sint ipsum doloribus</p>
</div>
@endsection