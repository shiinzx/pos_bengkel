

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3>Edit Category</h3>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('category.update', $category->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group mb-2">
                <label for="name">Nama</label>
                <input type="text" name="name" class="form-control"
                       value="<?php echo e(old('name', $category->name)); ?>" required>
            </div>

            <div class="form-group mb-2">
                <label for="description">Deskripsi</label>
                <input type="text" name="description" class="form-control"
                       value="<?php echo e(old('description', $category->description)); ?>" required>
            </div>

            <button type="submit" class="btn btn-success">Update</button>
            <a href="<?php echo e(route('category.index')); ?>" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\POS BARU\POS\resources\views/category/form_edit.blade.php ENDPATH**/ ?>