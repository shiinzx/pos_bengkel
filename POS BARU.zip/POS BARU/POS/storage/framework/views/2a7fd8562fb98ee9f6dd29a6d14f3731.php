<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($category->name); ?></h3>
<div class="row row-cols-1 row-cols-md-2 g-2">
    <?php $__currentLoopData = $category->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"><?php echo e($product->name); ?></h5>
        <input type="hidden" name="" class="id_product" value="<?php echo e($product->id); ?>">
        <h3 class="card-price"><?php echo e($product->price); ?></h3>
        <button class="btn-add btn btn-primary">Add</button>
    
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\ACER\OneDrive\ドキュメント\LARAVEL_POS\POS\resources\views/order/form.blade.php ENDPATH**/ ?>