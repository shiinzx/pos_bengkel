<script>
  $(function(){
    const orderedList = []
    let total = 0
    $('.btn-add').on('click', function(){
      const name = $(this).closest('.card-body').find('.card-title').text()
      const price = $(this).closest('.card-body').find('card-price').text()
      const id = $(this).closest('.card-body').find('.product_id').val()

      if(orderedList.every(list => list.id != id)){
        let dataN = {'id' : id, 'name' : name, 'qty' : 1, 'price' : price}
        orderedList.push(dataN)
        console.log(orderedList)
        let order = `
        <tr>
          <td>${name}</td>
          <td>1</td>
          <td>${price}</td>
          </tr>
        `
        $('#tbl-cart tbody').append(order)
      }else {
       const index = orderedList.findIndex(list => list.id == parseInt(id))
       console.log(orderedList[index])
       orderedList[index].qty += 1
       orderedList[index].price = orderedList[index].qty * orderedList[index].price
        cosole.log(orderedList)
      }

      
    })
  })
</script><?php /**PATH D:\POS BARU\POS\resources\views/order/script.blade.php ENDPATH**/ ?>